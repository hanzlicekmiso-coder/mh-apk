package sk.mhservis.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String START_URL = "https://mh.6f.sk";

    private WebView webView;
    private ProgressBar progressBar;
    private LinearLayout offlineBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        buildLayout();
        setupWebView();

        if (isOnline()) {
            showWeb();
            webView.loadUrl(START_URL);
        } else {
            showOffline();
        }
    }

    private void buildLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF4F7FB);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)
        ));

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1
        ));

        offlineBox = new LinearLayout(this);
        offlineBox.setOrientation(LinearLayout.VERTICAL);
        offlineBox.setGravity(Gravity.CENTER);
        offlineBox.setPadding(dp(26), dp(26), dp(26), dp(26));
        offlineBox.setVisibility(View.GONE);

        TextView title = new TextView(this);
        title.setText("Nie je internetové pripojenie");
        title.setTextSize(22);
        title.setTextColor(0xFF0F172A);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(10));
        offlineBox.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Skontroluj Wi‑Fi alebo mobilné dáta a skús to znova.");
        sub.setTextSize(15);
        sub.setTextColor(0xFF475569);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(18));
        offlineBox.addView(sub);

        Button retry = new Button(this);
        retry.setText("Skúsiť znova");
        retry.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (isOnline()) {
                    showWeb();
                    webView.loadUrl(START_URL);
                }
            }
        });
        offlineBox.addView(retry);

        root.addView(offlineBox, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1
        ));

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }

            @Override public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                super.onPageFinished(view, url);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress < 100 ? View.VISIBLE : View.GONE);
            }
        });
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkInfo info = cm.getActiveNetworkInfo();
        return info != null && info.isConnected();
    }

    private void showWeb() {
        offlineBox.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
    }

    private void showOffline() {
        webView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        offlineBox.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
