MH WebView APK projekt
======================

Toto je hotový Android Studio projekt pre jednoduchú APK aplikáciu.
Predvolená stránka je:
https://mh.6f.sk

Ako vytvoriť APK:
1. Otvor Android Studio.
2. File -> Open -> vyber priečinok MH_WebView_APK.
3. Počkaj, kým sa načíta Gradle.
4. Build -> Build App Bundle(s) / APK(s) -> Build APK(s).
5. Hotový APK nájdeš v:
   app/build/outputs/apk/debug/app-debug.apk

Zmena názvu aplikácie:
app/src/main/res/values/strings.xml

Zmena webovej adresy:
app/src/main/java/sk/mhservis/app/MainActivity.java
riadok:
private static final String START_URL = "https://mh.6f.sk";

Zmena balíka aplikácie:
app/build.gradle
applicationId 'sk.mhservis.app'
namespace 'sk.mhservis.app'

Funkcie:
- WebView aplikácia pre Android / Samsung S25
- fullscreen bez hornej lišty prehliadača
- JavaScript zapnutý
- cookies a úložisko cez WebView
- tlačidlo späť ide najprv v histórii stránky
- kontrola internetu
- vlastná hláška bez pripojenia
- jednoduchá ikona aplikácie
